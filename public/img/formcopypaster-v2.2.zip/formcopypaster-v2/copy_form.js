//Copy form scripts

var form = $('form').inputValues();
var storArray = JSON.stringify( form );

chrome.storage.local.set({
'newStorage': storArray
});
