chrome.commands.onCommand.addListener(function(command) {
  if (command === 'do_content') {
  	chrome.tabs.executeScript(null, { file: "jquery.min.js" }, function() {
  	    chrome.tabs.executeScript(null, {file: "copy_form.js"});
  	});
    
  }
  
  if (command === 'do_target') {
  	chrome.tabs.executeScript(null, { file: "jquery.min.js" }, function() {
  	    chrome.tabs.executeScript(null, {file: "paste_form.js"});
  	});
  }
});