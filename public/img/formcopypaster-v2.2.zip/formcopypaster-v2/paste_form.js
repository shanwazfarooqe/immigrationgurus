//Paste form scripts

var storedLegal = chrome.storage.local.get('newStorage', function (items) {
    //console.log(items); 

    var obj = JSON.parse(items.newStorage);
    for (var key in obj) {
    var key2 = key.substr(key.length - 18)
      if (obj.hasOwnProperty(key)) {
      	$('form').inputValues(key2, obj[key]);
      }
    }
   
  });